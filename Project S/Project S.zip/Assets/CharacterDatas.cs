﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class CharacterDatas : MonoBehaviour {
    public List<CharacterStat> Characters = new List<CharacterStat>();
    public List<CharacterStat> Enemys = new List<CharacterStat>();

    // Use this for initialization
    void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
